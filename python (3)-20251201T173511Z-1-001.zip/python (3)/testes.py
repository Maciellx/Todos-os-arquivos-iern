import random

# Lista de palavras
palavras = ["python", "banana", "computador", "foguete", "cachorro", "escola"]
palavra_secreta = random.choice(palavras)
letras_descobertas = ["_"] * len(palavra_secreta)
tentativas = 6
letras_erradas = []

print("🔤 Bem-vindo ao Jogo de Adivinhação de Palavra!")
print("Adivinhe a palavra secreta. Você tem 6 tentativas.")
print(" ".join(letras_descobertas))

# Loop do jogo
while tentativas > 0 and "_" in letras_descobertas:
    letra = input("Digite uma letra: ").lower()

    if not letra.isalpha() or len(letra) != 1:
        print("⚠️ Digite apenas uma letra!")
        continue

    if letra in letras_descobertas or letra in letras_erradas:
        print("⛔ Você já tentou essa letra.")
        continue

    if letra in palavra_secreta:
        for i in range(len(palavra_secreta)):
            if palavra_secreta[i] == letra:
                letras_descobertas[i] = letra
        print("✅ Letra correta!")
    else:
        tentativas -= 1
        letras_erradas.append(letra)
        print(f"❌ Letra incorreta! Tentativas restantes: {tentativas}")

    print("\nPalavra: ", " ".join(letras_descobertas))
    print("Letras erradas:", ", ".join(letras_erradas))

# Resultado final
if "_" not in letras_descobertas:
    print("\n🎉 Parabéns! Você adivinhou a palavra:", palavra_secreta)
else:
    print("\n💀 Fim de jogo! A palavra era:", palavra_secreta)
