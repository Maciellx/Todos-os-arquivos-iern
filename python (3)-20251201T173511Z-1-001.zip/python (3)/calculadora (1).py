#Menu da calculadora
def menu():
    menu1 = """
    Opções: 
    O Programa Ira Se Repitir Até Você Digitar 0
   ------------------------------------------
   | 1 - IMC                                |
   | 2 - Celsius Para Fahrenheit            |
   | 3 - Horas Para Minutos E segundos      |
   | 4 - Àrea do Triangulo                  |
   | 5 - Juros Simples                      |
   | 6 - Raiz Quadrada De Um Número         |
   | 7 - Juros Composto                     |
   | 8 - Porcentagem De Um Número           |
   | 9 - Teorema de Pitagoras               |
   | 0 - Sair do programa                   |
   ------------------------------------------
    """
    return menu1
print(menu())
#Calculo do IMC 1
def imc():
# menu
    intro = """
*************************************************************
* Bem-Vindo!                                                *
* Aqui Você ira Calcular Seu IMC(Indice de Massa Corporal)  *
*************************************************************
"""
    print(intro)
#laço de repetição sera quebrado se tiver um break
    while True:
        try:
#Entrada de dados
            peso = float(input("Por Favor Digite Seu Peso Em Kg: "))
            altura = float(input("Por Favor Digite Sua Altura Em Metros: "))
#Verificando se o numero e Positivo
            if peso <= 0 or altura <=0:
                print("\nDigite Apenas Números Maior Que 0\n")
                continue
            break
#caso o peso ou altura forem texto, entra aqui
        except ValueError:
            print("\nPor Favor Insira Apenas Números Positivos\n")
# operação do imc
    return  peso/(altura**2)
#Transformando celsius para fahrenheit 2
def fahrenheit():
    intro = """
    ***********************************************************
    * Bem-Vindo!                                              *
    * Aqui Você Ira Transformar Graus Celsius Para Fahrenheit *
    ***********************************************************
    """
    print(intro)
    while True:
        try: 
#Entrada de danos
            celsius = float(input("Digite a Temperatura Em Graus Celsius: "))
            break
#Caso o usuario digitar letras 
        except ValueError:
            print("\nPor Favor Insira Apenas Números\n")
#calculo do fahrenheit
    fahrenheit = (celsius* 1.8) + 32
    return fahrenheit
#Transformando Horas em minutos e segundos 3
def horas():
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Aqui Você Ira Transformar Horas Em Minutos E Segundos *
*********************************************************
"""  
    print (intro)
    while True:
        try:
#Entrada de dados
            horas = float(input("Digite Algum Horário Do Dia: "))
#verificando se o numero e positivo
            if horas <= 0:
                print("\nDigite Apenas Números Positivos\n")
                continue
#calculo de segundos e minutos 
            segundos = horas * 60
            minutos = segundos * 60
            return  segundos, minutos
#Caso o usuario digitar letras 
        except ValueError:
            print("\nPor favor Insira Apenas Números\n")
#Area do triangulo 4
def area():
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Aqui Você Ira Descobrir a Àrea De Um Triângulo        *
*********************************************************
"""  
    print (intro)
    while True:
        try:
#entrada de dados 
            base = float(input("Digite a Base Do Triângulo: "))
            altura = float(input("Digite a Altura Do Triângulo: "))
# Verificando se o numero e positivo 
            if base <=0 or altura <= 0:
                print("\nDigite Apenas Números Maior Que 0\n")
                continue
            break
#Caso o usuario digitar letras 
        except ValueError:
            print("\nApenas Números São Permitidos, Tente Novamente.\n")
#calculo da area
    return (altura*base)/2
#Juros 5
def juros_simples():
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Aqui Você Ira Calcular Juros Simples                  *
*********************************************************
"""  
    print (intro)
    while True:
        try:
# Entrada de dados
            C = float(input("Digite o Capital (Dinheiro Inicial): "))  # Capital
            i = float(input("Digite a Taxa de juros (em porcentagem): ")) #Porcentagem
            t = float(input("Digite o tempo de aplicação (Em Anos): "))  # Tempo de aplicação
            
# Verifica se os valores sao positivos
            if C <= 0 or i <= 0 or t <= 0:
                print("\nPor Favor, Insira Valores Positivos Para Todos Os Parâmetros.\n")
                continue
            break
#Caso o usuario digitar letras 
        except ValueError:
            print("\nEntrada Inválida. Tente Novamente.\n")

    # Cálculo dos juros simples
    p = i/100
    J = C * p * t

    return J
#Raiz de um número 6
def raiz():
    intro = """
*************************************************************
* Bem-Vindo!                                                *
* Aqui você Ira Descobrir Se Um Número Possui Raiz Quadrada *
*************************************************************
"""
    print(intro)
    while True:
        try:
#Entrada de danos
            numero = int(input("Digite Um Número Positivo Maior Que Zero: "))
#verifica se o numero e positivo
            if numero <= 0:
                print("Digite Apenas Números Inteiros Positivos, Tente Novamente.")
                continue
#calculo da raiz 
            raiz = numero**0.5
#se caso a raiz for inteira 
            if raiz == int(raiz):
                return f"O Número {numero} Possui Uma Raiz Quadrada Exata, Que É {int(raiz)}."
#se a raiz nao for inteira , ou seja com virgula
            else:
                return f"O Número {numero} Não possui Uma Raiz Quadrada Exata. Sua Raiz Aproximada é {raiz:.2f}."
        except ValueError:
            print("Por Favor, Insira Apenas Números Válidos.")
# juros compostos 7
def juros_compostos():
    # Introdução
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Aqui Você Ira Calcular Juros Compostos                *
*********************************************************
"""  
    print (intro)
    while True:
        try:
# Entrada de dados
            C = float(input("Digite O Capital (Dinheiro Inicial): "))  # Capital
            i = float(input("Digite A Taxa De Juros (Porcentagem): "))  # Taxa de juros
            t = float(input("Digite O Tempo De Aplicação (Em Anos): "))  # Tempo de aplicação
            
# Verificação de valores válidos
            if C <= 0 or i <= 0 or t <= 0:
                print("\nPor favor, Insira Valores Positivos Para Todos Os Parâmetros.\n")
                continue
            break
#Caso o usuario digitar letras 
        except ValueError:
            print("\nEntrada Inválida. Tente Novamente.\n")
    
    # Cálculo do montante (M) e da porcentagem
    p = i/100
    M = C * (1 + p) ** t
    
    # Cálculo dos juros (J)
    J = M - C
    
    # Exibição dos resultados
    print(f"O Montante Após {t} Anos É: R${M:.2f}")
    print(f"O Valor Dos juros Compostos É: R${J:.2f}")
#Porcentagem 8
def porcentagem ():
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Aqui Você Ira Calcular A Porcentagem De um Número     *
*********************************************************
"""  
    print (intro)
    while True:
        try:
#entrada de dados
            numero = float(input("Digite Um Número Positivo: "))
            porcentagem = float(input("Digite A Porcentagem: "))
#verifca se o numero e positivo
            if numero <= 0 or porcentagem <=0:
                print("Digite Apenas Número Positivos, Tente Novamente")
                continue
#se caso o numero for negativo ou 0 ele vai para o codigo e repitir novamente 
            break
        except ValueError:
            print("Por favor Insira Apenas Números")
#calculo da porcentagem
    return  (numero*porcentagem)/100
#Teorema de pitagoras 9
def teorema():
    intro = """
*************************************************************
* Bem-Vindo!                                                *
* Aqui Você ira Descobrir Apenas A Hipotenusa Usando Teorema*
* De Pitagoras                                              *
*************************************************************
"""
    print(intro)
    while True:
        try:
            cateto1 = float(input("Digite O Primeiro Cateto: "))
            cateto2 = float(input("Digite O Primeiro Cateto: "))
            if cateto1 <=0 or cateto2<= 0:
                print("Apenas Números Positivos")
                continue
            hipotenusa = ((cateto1**2) + (cateto2**2)) ** 0.5
            if hipotenusa == int(hipotenusa):
                return f"O cateto 1{cateto1} E O Cateto 2{cateto2} Possui Uma Hipotenusa Exata, Que É {int(hipotenusa)}."
            else:
                return f"O cateto 1{cateto1} E O Cateto 2{cateto2} Não possui Uma Hipotenusa Exata. Sua Hipotenusa Aproximada é {hipotenusa:2f}."
        except ValueError:
            print("Apenas Números")
#Menus de prints
contador = 1
def calculadora():
    while contador !=0:
        menu()  # Exibe o menu
        try:
            op = int(input("Digite o número da opção de 0 a 9: "))  # Solicita a opção do usuário
            if 0 <= op <= 9:  # Verifica se a opção está dentro do intervalo permitido
                if op == 0:
                    print("Você saiu do programa.")
                    break  # Encerra o loop e o programa se o usuário escolher 0
                elif op == 1:
                    print(f"\nSeu IMC é: {imc(): .2f}")
                elif op == 2:
                    print(f"\nA Temperatura Em Fahrenheit É: {fahrenheit(): .2f}")
                elif op == 3:
                    minutos, segundos = horas()
                    print(f"\nO resultado é: {minutos:} minutos e {segundos:} segundos.")
                elif op == 4:
                    print(f"\nA Àrea do Triângulo Séra: {area()}")
                elif op == 5:
                    print(f"\nO valor dos juros simples é: R${juros_simples()}")
                elif op == 6:
                    print(f"\n{raiz()}")
                elif op == 7:
                    print(f"\n{juros_compostos()}")
                elif op == 8:
                    print(f"O resultado sera: {porcentagem(): .2f}")
                elif op == 9:
                    print(f"\n {teorema()}")
            else:
                print("Número fora do intervalo permitido. Escolha um número entre 0 e 9.")
        except ValueError:
            print("Não pode digitar letras, apenas números. Por favor, insira um número de 0 a 9.")

        print(menu())
calculadora()