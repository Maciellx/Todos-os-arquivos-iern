function soma(){
    document.getElementById("valor1").innerHTML = '4';
    document.getElementById("valor2").innerHTML = '3';
    document.getElementById("resultado").innerHTML = '7';
}
soma()