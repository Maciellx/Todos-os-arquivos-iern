var contador = 1;
var jogo = "Marcos e viadinho safado gayzao boiolao molofofo";
    while(contador <= 10){
        document.write(contador+')'+jogo+'<br>');
        contador++;
    }
