import random

def menu():
    menu1 = """
    Opções: 
    O Programa Ira Se Repitir Até Você Digitar 0
   ------------------------------------------
   | 1 - Adivinhe o Número                  |
   | 2 - Pedra, Papel ou Tesoura            |
   | 3 - Cara ou Coroa                      |
   | 4 - Ìmpar ou Par                       |
   | 5 - Quiz Matemática                    |
   | 6 - Quiz Perguntas                     |
   | 7 - Número proibido                    |
   | 8 - Maior Ou Menor                     |
   | 9 - Para Ou Continuar                  |
   | 0 - Sair do programa                   |
   ------------------------------------------
    """
    return menu1

def adivinhe_o_numero():
    intro = """
*************************************************************
* Bem-Vindo!                                                *
* Aqui Você ira Adivinhar um número entre 1 e 100 !         *
* Você Tem 10 tentativas                                    *
*************************************************************
"""
    print(intro)

    numero = random.randint(1, 100)
    tentativas = 10

    while True:
        try:
            chute = int(input("Adivinhe o número de 1 a 100: "))
            if chute < 1 or chute > 100:
                print("Apenas números entre 1 e 100.\n")
                continue
            else:
                if chute == numero:
                    print(f"Acertouuuuuuuuuuuuuuuuuuuuu")
                    break
                elif chute < numero:
                    print("Muito baixo")
                elif chute > numero:
                    print("Muito alto")

                tentativas -= 1
                print(f"Você Tem {tentativas} tentativas restantes")

                if tentativas == 0:
                    print("Tentativas esgotadas")
                    break

        except ValueError:
            print("\nPor Favor Insira Apenas Números Positivos\n")

def p_p_t():
    intro = """
    ***********************************************************
    * Bem-Vindo!                                              *
    * Aqui Você Ira Jogar Pedra, Papel e Tesoura              *
    ***********************************************************
    """
    print(intro)
    while True:
        try:
            opcoes = ["pedra", "papel", "tesoura"]
            minha_escolha = input("Escolha pedra, papel ou tesoura: ").lower()

            if minha_escolha not in opcoes:
                print("Digite apenas pedra, papel ou tesoura\n")
                continue

            pedra_papel_tesoura = random.choice(opcoes)
            print(f"O computador escolheu {pedra_papel_tesoura}")
            
            if minha_escolha == pedra_papel_tesoura:
                print("Empate")
            elif minha_escolha == "pedra" and pedra_papel_tesoura == "tesoura" or minha_escolha == "papel" and pedra_papel_tesoura == "pedra" or minha_escolha == "tesoura" and pedra_papel_tesoura == "papel":
                print("Venceu")
            else:
                print("Perdeu")
            
            jogar_novamente = input("\nDeseja jogar novamente? (s/n): ").lower()
            if jogar_novamente != "s":
                break

        except ValueError:
            print("Apenas letras")

def cara_coroa():
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Aqui Você Ira Jogar Cara Ou Coroa                     *
*********************************************************
"""  
    print(intro)
    while True:
        try:
            lista = ["Cara", "Coroa"]
            escolha = input("Escolha 'cara' ou 'coroa': ").lower()

            if escolha != "cara" and escolha != "coroa":
                print("Digite apenas 'cara' ou 'coroa'.")
            else:
                Computador = random.choice(lista).lower()
                print("Resultado:", Computador)

                if escolha == Computador:
                    print("Você ganhou")
                else:
                    print("Você perdeu")
                    break
        except ValueError:
            print("Apenas Letras")

def impar_par():
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Aqui Você Ira Dizer Se o Número Ìmpar ou Par          *
*********************************************************
"""  
    print(intro)
    while True:
        try:
            num1 = random.randint(0, 10)
            num2 = random.randint(0, 10)
            soma = num1 + num2

            print(f"A soma dos dois números é: {soma}")
            resposta = input("A soma é par ou impar? ").lower()

            if resposta != "par" and resposta != "ímpar" and resposta != "impar":
                print("Digite apenas 'par' ou 'ímpar'.")
            else:
                if soma % 2 == 0 and resposta == "par":
                    print("acertou")
                    break
                elif soma % 2 != 0 and (resposta == "ímpar" or resposta == "impar"):
                    print("acertou")
                    break
                else:
                    print("errou")

        except ValueError:
            print("Apenas letras")

def tabuada():
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Aqui Você Ira Jogar Tabuada                           *
*********************************************************
""" 
    print(intro)
    while True:
        try:
            fator = random.randint(1, 100)
            numero = random.randint(1, 100)
            resposta_correta = numero * fator
            print(f"\nQuanto é {numero} x {fator}?")
            resposta = int(input("Sua resposta: "))
            if resposta == resposta_correta:
                print("Acertou")
                break
            else:
                print(f"Errou")
        except ValueError:
            print("Apenas Numeros")

def perguntas():
    intro = """
*************************************************************
* Bem-Vindo!                                                *
* Aqui você Ira Jogar Um Quiz De Perguntas *
*************************************************************
"""
    print(intro)
    try:
        pontuacao = 0
        print("\n1) Qual é o maior oceano do mundo?\n" \
        "a) Atlântico\n" \
        "b) Índico\n" \
        "c) Pacífico\n")
        resposta = input("Sua resposta: ").lower()

        if resposta == "c" or resposta == "pacífico":
            print("Acertou")
            pontuacao += 1
        else:
            print("Errou, a resposta correta era a letra c) Pacífico.")

        print("\n2) Quem descobriu o Brasil?\n" \
        "a) Pedro Álvares Cabral\n" \
        "b) Cristóvão Colombo\n" \
        "c) Dom Pedro I\n")
        resposta = input("Sua resposta: ").lower()

        if resposta == "a" or resposta == "pedro álvares cabral":
            print("Acertou")
            pontuacao += 1
        else:
            print("Errou, a resposta correta era a letra a) Pedro Álvares Cabral.")

        print("\n3) Qual planeta é conhecido como Planeta Vermelho?\n" \
        "a) Marte\n" \
        "b) Júpiter\n" \
        "c) Saturno\n")
        resposta = input("Sua resposta: ").lower()

        if resposta == "a" or resposta == "marte":
            print("Acertou")
            pontuacao += 1
        else:
            print("Errou, a resposta correta era a letra a) Marte.")

        print("\n4) Quanto é 7 x 8?\n" \
        "a) 54\n" \
        "b) 56\n" \
        "c) 58\n")
        resposta = input("Sua resposta: ").lower()

        if resposta == "b" or resposta == "56":
            print("Acertou")
            pontuacao += 1
        else:
            print("Errou, a resposta correta era a letra b) 56.")

        print(f"\nVocê acertou {pontuacao} de 4 perguntas!")
    except ValueError:
        print("Apenas Letras")

def numero_proibido():
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Aqui Você Não Pode Digitar O Número Proibido          *
*********************************************************
"""  
    print(intro)
    numero = random.randint(1, 10)
    numeros_digitados = []
    pontuacao = 0
    while True:
        try:
            entrada = input("Digite um número entre 1 e 10: ")
            numero1 = int(entrada)

            if numero1 < 1 or numero1 > 10:
                print("O número deve estar entre 1 e 10.")
                continue

            if numero1 in numeros_digitados:
                print("Você já digitou esse número, tente outro.")
                continue

            numeros_digitados.append(numero1)

            if numero1 == numero:
                print(f"Você perdeu, Digitou o número proibido, sua pontuação foi {pontuacao} acertos.")
                break
            else:
                print("Tudo certo, continue.")
                pontuacao += 1
        except ValueError:
            print("Apenas Números")

def maior_ou_menor():
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Aqui Você Dizer Se o Proximo Número é Maior Ou Menor  *
*********************************************************
"""
    print(intro)
    while True:
        try:
            atual = random.randint(1, 50)
            pontos = 0
            print(f"\nNúmero atual: {atual}")
            escolha = input("O próximo número será maior ou menor? (maior/menor): ").lower()

            if escolha not in ["maior", "menor"]:
                print("Digite apenas 'maior' ou 'menor'.")
                continue

            proximo = random.randint(1, 50)
            print(f"Número sorteado: {proximo}")

            if escolha == "maior" and proximo > atual or escolha == "menor" and proximo < atual:
                print("Acertou")
                pontos += 1
                atual = proximo
            else:
                print("Errou!")
                print(f"Cabou, Sua pontuação foi: {pontos}")
                break
        except ValueError:
            print("Apenas números")

def parar():
    intro = """
*********************************************************
* Bem-Vindo!                                            *
* Jogo: Parada ou Continua                              *
* Some pontos a cada rodada, mas cuidado com o 0!       *
*********************************************************
"""
    print(intro)
    pontos = 0

    while True:
        escolha = input("Deseja continuar? (s/n): ").lower().strip()

        if escolha == "s":
            numero = random.randint(0, 15)
            print(f"Número sorteado: {numero}")

            if numero == 0:
                print("Caiu 0, você perdeu!")
                pontos = 0
                break
            else:
                pontos += numero
                print(f"Você somou {numero} pontos. Total: {pontos}")

        elif escolha == "n":
            print(f"\nVocê parou com {pontos} pontos.")
            break
        else:
            print("Digite apenas 's' para continuar ou 'n' para parar.")

while True:
    print(menu())
    try:
        opcao = int(input("Escolha uma opção: "))
        if opcao == 1:
            adivinhe_o_numero()
        elif opcao == 2:
            p_p_t()
        elif opcao == 3:
            cara_coroa()
        elif opcao == 4:
            impar_par()
        elif opcao == 5:
            tabuada()
        elif opcao == 6:
            perguntas()
        elif opcao == 7:
            numero_proibido()
        elif opcao == 8:
            maior_ou_menor()
        elif opcao == 9:
            parar()
        elif opcao == 0:
            print("Cabo")
            break
        else:
            print("Opção inválida. Tente novamente.")
    except ValueError:
        print("Entrada inválida. Por favor, insira um número.")
