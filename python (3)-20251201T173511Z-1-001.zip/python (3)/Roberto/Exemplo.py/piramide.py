seila = '*'
contador = int(input("Digite o tamanho da pirâmide: "))
largura_total = 2 * contador - 1
nivel = 1
while nivel <= contador:
    qtd_asteriscos = 2 * nivel - 1
    linha = seila * qtd_asteriscos
    print(linha.center(largura_total))
    nivel += 1