def soma(num):
    tab = 0
    while tab <= 10:
        print(f"{num} + {tab} = {num + tab}")
        tab = tab + 1

def sub(num):
    tab = 0
    while tab <= 10:
        sub = tab - num
        if sub <0:
          sub = sub *-1
          print(f"{tab} - {num} = {sub}")
        else:
            print(f"{tab} - {num} = {sub}")
        tab = tab + 1

def multi(num):
    tab = 0
    while tab <= 10:
        print(f"{num} x {tab} = {num * tab}")
        tab = tab + 1

def div(num):
    tab = 0
    while tab <= 10:
        if num == 0:
            print("Não é posivel dividir por 0 ")
        else:
            print(f"{tab} / {num} = {tab/num}")
            tab = tab + 1

def menu():
    print(""
    "MENU DA TABUADA\n"
    "1-Soma\n"
    "2-Subtrair\n"
    "3-Multiplicar\n"
    "4-Dividir\n"
    "5- Sair\n")


contador = 1  
while contador == 1:
    menu()
    escolha = int(input("Escolha umas das opções acima: "))
    num = int(input("Digite o numero: "))

    if escolha == 1:
        soma(num)
    elif escolha == 2:
        sub(num)
    elif escolha == 3:
        multi(num)
    elif escolha == 4:
        div(num)
    elif escolha == 5:
        break