saldo = 1000.0  # saldo inicial
senha_correta = "1234"
tentativas = 0
max_tentativas = 3

print("=== CAIXA ELETRÔNICO ===")

# Etapa 1: Login com senha
while tentativas < max_tentativas:
    senha = input("Digite sua senha: ")

    if senha == senha_correta:
        print("Acesso autorizado. Bem-vindo!")
        
        # Etapa 2: Menu de operações
        while True:
            print("\n--- Menu ---")
            print("1 - Ver saldo")
            print("2 - Sacar dinheiro")
            print("3 - Depositar dinheiro")
            print("4 - Sair")

            opcao = input("Escolha uma opção: ")

            if opcao == "1":
                print("Seu saldo atual é R$",saldo)

            elif opcao == "2":
                valor = float(input("Digite o valor do saque: "))
                if valor <= 0:
                    print("Valor inválido.")
                elif valor > saldo:
                    print("Saldo insuficiente.")
                else:
                    saldo = saldo - valor
                    print("Saque de R$ ",valor," realizado com sucesso.")
                    print("Saldo restante: R$ ",saldo)

            elif opcao == "3":
                valor = float(input("Digite o valor do depósito: "))
                if valor <= 0:
                    print("Valor inválido.")
                else:
                    saldo = saldo + valor
                    print("Depósito de R$ ",valor," realizado com sucesso.")
                    print("Saldo atualizado: R$ ",saldo)

            elif opcao == "4":
                print("Voçê saiu do sistema")
                break

            else:
                print("Opção inválida. Tente novamente.")

        break  

    else:
        tentativas = tentativas + 1
        print("Senha incorreta.")
        if tentativas == max_tentativas:
            print("Acesso bloqueado. Tente novamente mais tarde.")