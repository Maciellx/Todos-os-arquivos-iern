print("=== SISTEMA DE VOTAÇÃO ===")

votos_candidato1 = 0
votos_candidato2 = 0
votos_nulos = 0
votos_brancos = 0

while True:
    print("\nEm quem você deseja votar?")
    print("1 - LUCAS")
    print("2 - JOÃO VITOR")
    print("3 - Voto Nulo")
    print("4 - Voto em Branco")
    print("0 - Encerrar votação")

    voto = input("Digite o número da sua opção: ")

    if voto == "1":
        votos_candidato1 = votos_candidato1 + 1
        print("Voto registrado para Candidato A.")
    elif voto == "2":
        votos_candidato2 = votos_candidato2 + 1
        print("Voto registrado para Candidato B.")
    elif voto == "3":
        votos_nulos = votos_nulos + 1
        print("Voto nulo registrado.")
    elif voto == "4":
        votos_brancos = votos_brancos + 1
        print("Voto em branco registrado.")
    elif voto == "0":
        print("\nEncerrando votação...")
        break
    else:
        print("Opção inválida. Tente novamente.")

# Exibindo o resultado
print("\n=== RESULTADO FINAL ===")
print("Candidato A: ",votos_candidato1," voto(s)")
print("Candidato B: ",votos_candidato2," voto(s)")
print("Nulos: ",votos_nulos," voto(s)")
print("Brancos: ",votos_brancos," voto(s)")

# Verificando quem ganhou
if votos_candidato1 > votos_candidato2:
    print("Candidato A venceu a eleição!")
elif votos_candidato2 > votos_candidato1:
    print("Candidato B venceu a eleição!")
else:
    print("A eleição terminou empatada.")