nome_do_produto = []
preco_do_produto = []
quantidade_do_produto = []

def Menu():
        print("1. Cadastrar produto\n" \
        "2. Listar produtos\n" \
        "3. Atualizar quantidade\n" \
        "4. Remover produto\n" \
        "5. Sair\n" \
        "")

def cadastrar_produto():
    try:
        nome_produto = str(input("Digite o nome do produto: "))
        if nome_produto in nome_do_produto:
            print("Produto já existente")
        else:
            preco_produto = float(input("Digite o preco do produto"))
            if preco_produto <0:
                print("Valor invalido, digite um valor maior que 0")
            else:
                quantidade_produto = int(input("Digite a quantidade de produto: "))
                if quantidade_produto <0:
                    print("Valor invalido, digite um valor maior que 0")
                else:
                    nome_do_produto.append(nome_produto)
                    preco_do_produto.append(preco_produto)
                    quantidade_do_produto.append(quantidade_produto)
    except ValueError:
        print("Digite corretamente os dados.")

def listar_produtos():
    if len(nome_do_produto) == 0:
        print("Estoque vazio.")
    else:
        for i in range(len(nome_do_produto)):
            print(f"{i + 1}. {nome_do_produto[i]} - R${preco_do_produto[i]:.2f} - {quantidade_do_produto[i]} unidades")

def atualizar_quantidade():
    if len(nome_do_produto) == 0:
        print("Não há produtos no estoque.")
    else:
        listar_produtos()
        try:
            produto = int(input("Digite o número do produto para atualizar a quantidade: "))
            if 0 <= produto < len(nome_do_produto):
                    nova_qtd = int(input("Nova quantidade: "))
                    if nova_qtd < 0:
                        print("Quantidade não pode ser negativa.")
                    else:
                        quantidade_do_produto[produto] = nova_qtd
                        print("Quantidade atualizada com sucesso.")
            else:
                print("Dados inválido.")
        except ValueError:
            print("Entrada inválida.")

def remover_produto():
    if len(nome_do_produto) == 0:
        print("Não há produtos para remover.")
    else:
        listar_produtos()
        try:
            numero = int(input("Digite o número do produto para remover: ")) - 1
            if 0 <= numero < len(nome_do_produto):
                nome_removido = nome_do_produto.pop(numero)
                preco_do_produto.pop(numero)
                quantidade_do_produto.pop(numero)
                print(f"Produto '{nome_removido}' removido com sucesso.")
            else:
                print("Número inválido.")
        except ValueError:
            print("Entrada inválida.")

while True:
    Menu()
    try:
        opcao = int(input("Escolha uma opção: "))
        if opcao == 1:
            cadastrar_produto()
        elif opcao == 2:
            listar_produtos()
        elif opcao == 3:
            atualizar_quantidade()
        elif opcao == 4:
            remover_produto()
        elif opcao == 5:
            break
    except ValueError:
        print("Entrada inválida. Por favor, insira um número.")