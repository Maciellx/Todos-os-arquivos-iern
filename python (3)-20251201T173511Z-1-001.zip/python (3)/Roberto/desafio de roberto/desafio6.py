import random

print("🎉 Bem-vindo ao jogo de adivinhação! 🎯")
print("🤔 Estou pensando em um número entre 1 e 100..."\
"Você tem 10 tentativas!\n\n Adivinhe qual é, hahaha\n\n")

numero_secreto = random.randint(1,100)
max_tentativas = 10

for tentativa in range(1, max_tentativas + 1):
    palpite = int(input("Digite seu palpite 👉: "))
    if palpite == numero_secreto:
        print("🎉 Parabéns! Você acertou o número ",numero_secreto," em ",tentativa," tentativas!")
        break
    elif palpite < numero_secreto:
        print("📈 O número é maior!")
    else:
        print("📉 O número é menor!")

else:
    print("😢😢😢😢😢😢😢😢😢😢😢😢😢" \
    "Suas tentativas acabaram! O número era:",numero_secreto)