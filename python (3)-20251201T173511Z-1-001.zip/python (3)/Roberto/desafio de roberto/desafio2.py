# O computador escolhe um número secreto (nós definimos manualmente, 
# já que não vamos usar bibliotecas agora) 
# e o jogador tenta adivinhar 
# com dicas se o número é maior ou menor até acertar.

print("=== JOGO DE ADIVINHAÇÃO ===")

numero_secreto = 7  # número fixo entre 1 e 10
tentativas = 0
chute = 0

print("Tente adivinhar o número entre 1 e 10!")

while chute != numero_secreto:
    chute = int(input("Digite o número para adivinhar: "))
    tentativas = tentativas + 1

    if chute < 1 or chute > 10:
        print("Número fora do intervalo! Tente entre 1 e 10.")
    elif chute < numero_secreto:
        print("É mais!")
    elif chute > numero_secreto:
        print("É menos!")
    else:
        print("Parabéns! Você acertou o número ",numero_secreto," em ",tentativas," tentativa(s).")

print("Fim do jogo.")