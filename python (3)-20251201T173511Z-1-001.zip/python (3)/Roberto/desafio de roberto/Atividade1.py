lista = []
def menu():
    print("Menu de opções:\n" \
    "1. Adicionar nomes à lista.\n" \
    "2. Adicionar vários nomes de uma vez.\n" \
    "3. Inserir um convidado em uma posição específica.\n" \
    "4. Remover um convidado pelo nome.\n" \
    "5. Remover um convidado por posição.\n" \
    "6. Limpar toda a lista.\n" \
    "7. Mostrar a posição de um nome na lista.\n" \
    "8. Contar quantas vezes um nome aparece.\n" \
    "9. Ordenar a lista de convidados.\n" \
    "10. Inverter a ordem dos nomes.\n" \
    "11. Criar uma cópia da lista original.\n" \
    "12. Mostar a lista de convidados.\n" \
    "0. Sair.\n")
#feito
def adicionar_nome():
    nome = input("Digite o nome do convidado (Apenas letras): ")
    if nome.isalpha():
        lista.append(nome)
        print(f"{nome} adicionado à lista.")
    else:
        print("Nome inválido. Digite apenas letras, sem espaços ou números.")
#feito
def adicionar_varios_nomes():
    novos_nomes = input('Digite nomes separados por vírgula: ').split(',')
    
    for nome in novos_nomes:
        nome_limpo = nome.strip()
        if nome_limpo.isalpha():
            lista.append(nome_limpo)
            print(f"{nome_limpo} adicionado à lista.")
        else:
            print(f"'{nome_limpo}' é inválido. Use apenas letras, sem espaços, números ou símbolos.")
#feito
def inserir_convidado():
    try:
        nome = input("Digite o nome:")
        posicao = int(input("Digite a posição onde deseja inserir o convidado: "))
        
        if posicao < 0 or posicao > len(lista):
            print(f"Posição inválida. A posição deve estar entre 0 e {len(lista)}.")
        elif nome.isalpha():
            lista.insert(posicao, nome)
            print(f"{nome} adicionado à lista na posição {posicao}.")
        else:
            print("Apenas letras")

    except ValueError:
        print("Você deve digitar um número inteiro para a posição.")
#feito
def remover_convidado_nome():
    nome = input("Digite o nome do convidado que deseja remover: ")
    if nome in lista:
        lista.remove(nome)
        print(f"{nome} removido da lista.")
    else:
        print(f"{nome} não encontrado na lista.")
#feito
def remover_convidado_posicao():
    print(lista)
    nome = input('Digite o nome para saber sua posição: ')
    if nome in lista:
        print(lista.index(nome))
        posicao = int(input(" Agora digite a posição para : "))
        if posicao < 0 or posicao > len(lista):
            print(f"Posição inválida. A posição deve estar entre 0 e {len(lista)}.")
        else:
            removido = lista.pop(posicao)
            print('Removido:', removido)
            print(lista)
    else:
        print("A pessoa que você procurou não esta na lista ")
#feito
def limpar_lista():
    certeza = input("Tem certeza que deseja limpar a lista? (s/n): ")
    if certeza == 's':
        lista.clear()
        print("Lista limpa.")
    else:
        print("Operação cancelada.")
# feito
def mostrar_posicao():
    nome = input("Digite o nome do convidado: ")
    if nome in lista:
        posicao = lista.index(nome)
        print(f"{nome} está na posição {posicao}.")
    else:
        print(f"{nome} não encontrado na lista.")
#feito
def contar_nome():
    nome = input("Digite o nome do convidado: ")
    contagem = lista.count(nome)
    print(f"{nome} aparece {contagem} vezes na lista.")
#feito
def ordenar_lista():
    lista.sort()
    print("Lista ordenada.")
    print(lista)
#feito
def inverter_lista():
    lista.reverse()
    print("Lista invertida.")
    print(lista)
#feito
def copiar_lista():
    copia = lista.copy()
    print("Cópia da lista criada.")
    print(copia)
#feito
def mostrar_lista():
    print(f"Lista de convidados: {lista}")

while True:
    menu()
    try:
        opcao = int(input("Escolha uma opção: "))
        if opcao == 1:
            adicionar_nome()
        elif opcao == 2:
            adicionar_varios_nomes()
        elif opcao == 3:
            inserir_convidado()
        elif opcao == 4:
            remover_convidado_nome()
        elif opcao == 5:
            remover_convidado_posicao()
        elif opcao == 6:
            limpar_lista()
        elif opcao == 7:
            mostrar_posicao()
        elif opcao == 8:
            contar_nome()
        elif opcao == 9:
            ordenar_lista()
        elif opcao == 10:
            inverter_lista()
        elif opcao == 11:
            copiar_lista()
        elif opcao == 12:
            mostrar_lista()
        elif opcao == 0:
            print("Saindo...")
            break
        else:
            print("Opção inválida. Tente novamente.")
    except ValueError:
        print("Entrada inválida. Por favor, insira um número.")