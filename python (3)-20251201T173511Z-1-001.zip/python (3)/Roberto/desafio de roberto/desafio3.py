# Variáveis globais
compras_realizadas = 0
total_gasto = 0.0
tem_reclamacao = False
tem_elogio = False

def menu():
    print("\nComo podemos te ajudar hoje?")
    print("1 - Fazer uma compra")
    print("2 - Registrar uma reclamação")
    print("3 - Registrar um elogio")
    print("4 - Sair")
    return input("Digite o número da opção: ")

def fazer_compra():
    global compras_realizadas, total_gasto
    produto = str(input("Qual produto você comprar? "))
    preco = float(input("Qual o valor do produto ? R$ "))
    compras_realizadas = compras_realizadas + 1
    total_gasto = total_gasto + preco
    print("Compra registrada: ",produto," por R$ ",preco)

def registrar_reclamacao():
    global tem_reclamacao, reclamacao
    reclamacao = input("Por favor, descreva sua reclamação: ")
    tem_reclamacao = True
    print("Sentimos muito! Sua reclamação foi registrada.")

def registrar_elogio():
    global tem_elogio, elogio
    elogio = str(input("Ficamos felizes! Deixe seu elogio: "))
    tem_elogio = True
    print("Agradecemos muito pelo carinho!")

def mostrar_resumo():
    print("\n=== RESUMO DO ATENDIMENTO ===")
    print("Compras realizadas: ",compras_realizadas)
    print("Total gasto: R$ ",total_gasto)


    if tem_reclamacao:
        print(f"Você fez {reclamacao} reclamação.")
    if tem_elogio:
        print(f"Você deixou {elogio} elogio.")
    if not tem_reclamacao and not tem_elogio:
        print("Sem manifestações.")

    print("Volte sempre! 💙")

def main():
    print("=== BEM-VINDO AO ATENDIMENTO VIRTUAL ===")

    while True:
        opcao = menu()

        if opcao == "1":
            fazer_compra()
        elif opcao == "2":
            registrar_reclamacao()
        elif opcao == "3":
            registrar_elogio()
        elif opcao == "4":
            print("\nEncerrando atendimento...")
            mostrar_resumo()
            break
        else:
            print("Opção inválida. Tente novamente.")

# Inicia o programa
main()