qtd_idade = 0
mulher = 0
masculino = 0
nome1 = ""

for i in range(0,4,1):
    nome = str(input("Informe seu nome: "))
    idade = int(input("Informe sua idade: "))
    nome1 = nome
    qtd_idade = qtd_idade + idade
    sexo = str(input("Informe seu sexo: "))
    if idade<=20 and sexo == "feminino":
        mulher = mulher + 1
    elif sexo == "masculino":
        masculino = masculino + 1
    elif idade > idade and sexo == "maculino":
        nome1 = nome
        
print("A média de idade é: ",qtd_idade/4)
print("Tem",mulher,"menores de 20 anos")
print("O homem mais velho é: ",nome1)