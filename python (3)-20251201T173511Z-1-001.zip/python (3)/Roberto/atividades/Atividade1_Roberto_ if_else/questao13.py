salario = float(input("Digite o salário do funcionário: "))
aumento = salario * 0.15
novo_salario = salario + aumento
print(f"O novo salário com aumento de 15% é R$ {novo_salario}")