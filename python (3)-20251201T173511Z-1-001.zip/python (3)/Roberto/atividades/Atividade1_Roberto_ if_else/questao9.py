num1 = int(input("Insira o primerio número: "))
num2 = int(input("Insira o segundo número: "))
num3 = int(input("Insira o terceiro número: "))

soma = (num1 + num2 + num3) / 3

print(f"A média do {num1}, {num2}, e {num3}, é {soma}")