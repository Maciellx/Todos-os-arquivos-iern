numero = float(input("Digite um número: "))

if 10 <= numero <= 100:
    print("O número está dentro do intervalo de 10 a 100.")
else:
    print("O número está fora do intervalo de 10 a 100.")