def verifica():

    idade = int(input("Digite sua idade: "))
    if 0 <= idade <= 120:
        print(f"{idade} é uma idade válida.")
    else:
        print(f"{idade} não é uma idade válida.")

verifica()
