metros = float(input("Digite um valor em metros: "))
centimetros = metros * 100
milimetros = metros * 1000
print(f"{metros} metros equivalem a {centimetros} centímetros e {milimetros} milímetros.")