def converte():
    metros = float(input("Digite o valor em metros: "))
    
    centimetros = metros * 100
    milimetros = metros * 1000
    
    print(f"{metros} metros equivalem:")
    print(f"{centimetros} centímetros")
    print(f"{milimetros} milímetros")

converte()
