def produto():
    produto1 = float(input("Digite o preço do produto com desconto: "))
    desconto = (produto1*0.10)
    desconto = produto1 - desconto
    return(f"O desconto final sera {desconto}")
print(produto())