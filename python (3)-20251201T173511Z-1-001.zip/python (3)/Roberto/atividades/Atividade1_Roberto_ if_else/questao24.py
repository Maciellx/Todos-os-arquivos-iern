def num():
    num1 = float(input("Digite um numero: "))

    if 0< num1 <9:
        return("numero positivo")
    elif num1 > 10:
        return("numero positivo e maior que 10")
    elif num1 == 0:
        return("Zero")
    else:
        return("numero negativo")
print(num())