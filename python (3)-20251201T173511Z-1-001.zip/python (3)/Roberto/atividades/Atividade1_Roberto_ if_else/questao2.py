ano = int(input("Informe o ano do seu nascimente: "))
if ano <= 2007:
    print("Você esta apto a votar Párabens")
else:
    print("Você não esta apto a votar que pena ")