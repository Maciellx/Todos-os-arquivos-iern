def soma():
    num1 = float(input("Digite o primerio numero para ser somado: "))
    num2 = float(input("Digite o segundo numero para ser somado: "))
    soma = num1 + num2
    return (f"A soma sera {soma}")
print(soma())