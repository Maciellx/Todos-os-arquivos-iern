
def iguais():
    num1 = float(input("Digite o primerio numero: "))
    num2 = float(input("Digite o segundo numero: "))

    if num1 == num2:
        return("os numeros sao iguas")
    elif num1 == 0 and num2 == 0:
        return("Zero")
    else:
        return("os numeros sao diferentes")
    
print(iguais())