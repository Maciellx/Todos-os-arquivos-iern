def diferença():
    num1 = float(input("Digite um numero para saber a diferança dele para 100: "))
    diferença1 = 100 - num1
    if diferença1 <0:
        diferença1=diferença1*-1
        return (f"O numero {num1} tem uma diferença de {diferença1} ate 100")
    else:
        return (f"O numero {num1} tem uma diferença de {diferença1} ate 100")

print(diferença())