def calcula_imc():
    peso = float(input("Digite seu peso (kg): "))
    altura = float(input("Digite sua altura (m): "))

    imc = peso / (altura ** 2)

    print(f"Seu IMC é: {imc}")

calcula_imc()
