def impar():
    num1 = int(input("Digite um numero: "))
    if num1 %2==0:
        print("Par")
    else:
        print("Impar")
impar()