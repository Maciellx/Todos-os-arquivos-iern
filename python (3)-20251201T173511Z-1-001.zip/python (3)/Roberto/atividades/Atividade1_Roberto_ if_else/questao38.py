def verifica():
    numero = float(input("Digite um número: "))
    
    if -1000 <= numero <= 1000:
        print(f"O número {numero} está no intervalo de -1000 a 1000.")
    else:
        print(f"O número {numero} nao está no intervalo de -1000 a 1000.")
verifica()
