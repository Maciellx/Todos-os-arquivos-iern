num1 = int(input("Digite um número interio: "))

quadrado = num1 **2
cubo = num1 **3

print(f"o quadrado do {num1} é {quadrado} e seu cubo é {cubo}")