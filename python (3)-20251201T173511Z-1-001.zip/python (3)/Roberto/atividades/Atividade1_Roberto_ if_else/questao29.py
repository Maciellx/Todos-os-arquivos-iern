def soma100():
    num1 = float(input("Digite o primerio numero: "))
    num2 = float(input("Digite o segundo numero: "))
    soma = num1 + num2
    if soma > 100:
        return(f"A soma de {num1} e {num2} é {soma}, que é maior que 100")
    else:
        return(f"A soma de {num1} e {num2} é {soma}, que nao é maior que 100.")
print(soma100())