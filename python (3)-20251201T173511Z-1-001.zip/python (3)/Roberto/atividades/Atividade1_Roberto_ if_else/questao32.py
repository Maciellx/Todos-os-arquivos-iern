def negativo():
    numero = int(input("Digite um número: "))

    if numero >0:
        print(f"o número {numero} é positivo")
    elif numero <0:
        print(f"o número {numero} é negativo")
    elif numero == 0:
        print("Zero")
    else:
        print("O numero é zero")