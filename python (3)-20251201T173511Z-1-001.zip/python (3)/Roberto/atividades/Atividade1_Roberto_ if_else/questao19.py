num1 = int(input("digite um numero e ira descobrir se ele e multiplo de 5: "))

if num1 % 5 == 0:
    print("Ele é multiplo de 5")
else:
    print("Ele não é multiplo de 5")