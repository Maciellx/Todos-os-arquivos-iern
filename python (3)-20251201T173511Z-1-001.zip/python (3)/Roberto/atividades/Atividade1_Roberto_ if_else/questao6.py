aa = int(input("Informe um número para saber sua tabuada de subtração de 1 a 10: "))
print(f"\nA tabuada de subtração do número {aa} (com resultados sempre positivos) é:\n")

resultado = 1 - aa
if resultado < 0:
    resultado = resultado * -1
print(f"1 - {aa} = {resultado}")

resultado = 2 - aa
if resultado < 0:
    resultado = resultado * -1
print(f"2 - {aa} = {resultado}")

resultado = 3 - aa
if resultado < 0:
    resultado = resultado * -1
print(f"3 - {aa} = {resultado}")

resultado = 4 - aa
if resultado < 0:
    resultado = resultado * -1
print(f"4 - {aa} = {resultado}")

resultado = 5 - aa
if resultado < 0:
    resultado = resultado * -1
print(f"5 - {aa} = {resultado}")

resultado = 6 - aa
if resultado < 0:
    resultado = resultado * -1
print(f"6 - {aa} = {resultado}")

resultado = 7 - aa
if resultado < 0:
    resultado = resultado * -1
print(f"7 - {aa} = {resultado}")

resultado = 8 - aa
if resultado < 0:
    resultado = resultado * -1
print(f"8 - {aa} = {resultado}")

resultado = 9 - aa
if resultado < 0:
    resultado = resultado * -1
print(f"9 - {aa} = {resultado}")

resultado = 10 - aa
if resultado < 0:
    resultado = resultado * -1
print(f"10 - {aa} = {resultado}")
5
