def verifica_triangulo():
    a = float(input("Digite o primeiro lado: "))
    b = float(input("Digite o segundo lado: "))
    c = float(input("Digite o terceiro lado: "))

    if a + b > c and a + c > b and b + c > a:
        print("Os lados podem formar um triângulo!")
    else:
        print("Os lados nao podem formar um triângulo.")

verifica_triangulo()
