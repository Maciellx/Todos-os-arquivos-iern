def calcula():
    nome = input("Digite seu nome: ")
    ano_nascimento = int(input("Digite seu ano de nascimento: "))
    sexo = input("Digite seu sexo (masculino/feminino): ").strip().lower()
    
    idade_atual = 2025 - ano_nascimento 
    
    if sexo == "masculino":
        idade_aposentadoria = 65
    elif sexo == "feminino":
        idade_aposentadoria = 60
    else:
        print("Sexo inválido. Use 'masculino' ou 'feminino'.")
    
    anos_faltando = idade_aposentadoria - idade_atual

    print(f"Nome: {nome}")
    print(f"Idade: {idade_atual} anos")
    print(f"Sexo: {sexo.capitalize()}")
    
    if anos_faltando > 0:
        print(f"Faltam {anos_faltando} anos para se aposentar.")
    else:
        print("Já pode se aposentar!")

calcula()
