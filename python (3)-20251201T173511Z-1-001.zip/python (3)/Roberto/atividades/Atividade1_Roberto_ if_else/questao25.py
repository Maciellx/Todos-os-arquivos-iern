def salario():
    salario1 = float(input("Digite o salário do funcionário: "))
    aumento = salario1 * 0.15
    novo_salario = salario1 + aumento
    return(f"O novo salário com aumento de 15% é R$ {novo_salario}")

print(salario())