nome = str(input("Digite seu nome: "))
print (f"Boa Vindas Ao IERN {nome}")