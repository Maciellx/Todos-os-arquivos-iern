def meta():
    num1 = int(input("Digite um número interio: "))

    dobro = num1 *2
    metade= num1 /2

    print(f"a metade do {num1} é {metade} e seu dobro é {dobro}")
meta()