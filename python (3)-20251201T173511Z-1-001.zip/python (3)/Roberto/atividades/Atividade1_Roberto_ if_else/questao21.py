def nome():
    nome = str(input("digite seu nome: "))
    return (f"Boas vindas {nome}")

print (nome())