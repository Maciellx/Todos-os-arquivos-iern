num1 = int(input("Informe o primerio número: "))
num2 = int(input("Informe o seugundo número: "))

if num1 > num2:
    print(f"o número {num1} é maior que {num2}")
elif num1 < num2:
    print(f"o número {num2} é maior que {num1}")
else:
    print("Os números são iguais1")