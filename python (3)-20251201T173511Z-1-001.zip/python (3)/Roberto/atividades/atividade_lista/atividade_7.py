livros = []
status = []

def menu():
    print("1. Adicionar Livros.\n" \
    "2. Listar livros.\n" \
    "3. Emprestar Livros.\n" \
    "")

def adicionar_livro(titulo):
    livros.append(titulo)
    status.append("Disponível")

def listar_livros():
    for i in range(len(livros)):
        print(f"{i}: {livros[i]} - {status[i]}")

def emprestar_livro(indice):
    if status[indice] == "Disponível":
        status[indice] = "Emprestado"
        print(f"Livro '{livros[indice]}' emprestado com sucesso.")
    else:
        print(f"Livro '{livros[indice]}' já está emprestado.")

def devolver_livro(indice):
    status[indice] = "Disponível"
    print(f"Livro '{livros[indice]}' devolvido com sucesso.")

