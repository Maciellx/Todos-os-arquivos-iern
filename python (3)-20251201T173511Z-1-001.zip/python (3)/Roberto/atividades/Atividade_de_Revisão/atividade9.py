def gerar_status_humor(codigo_humor):
    if codigo_humor == 1:
        print("Status atual: Sentindo-se ótimo")
    elif codigo_humor == 2:
        print("Status atual: Sentindo-se Pensativo")
    elif codigo_humor == 3:
        print("Status atual: Sentindo-se Precisando de café!")
    else:
        print("Status atual: indefinido")

codigo_humor = int(input("Digite o código do humor (1-ótimo, 2-pensativo, 3-precisando de um café): "))
gerar_status_humor(codigo_humor)