print("Bem vindo aqui você ira controlar um robô teimoso\n " \
"O robô so obedece comando espeficicos como: andar, parar e girar\n " \
"Você tambem pode desligar o robo usando o comando desligar")

while True:
    comando = input("Digite o comando que deseja dar ao robô: ")
    if comando == "andar":
        print("O robô andou")
    elif comando == "parar":
        print("O robô parou")
    elif comando == "girar":
        print("O robô girou")
    elif comando == "desligar":
        print("O robô foi desligado")
        break
    else:
        print("Comando inválido, tente 'andar' 'parar' ou 'girar'")