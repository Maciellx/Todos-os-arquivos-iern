def humor_dragao(cor_escamas):
    if cor_escamas == "verde":
        humor = "Calmo"
    elif cor_escamas == "vermelho":
        humor = "Furioso"
    elif cor_escamas == "azul":
        humor = "Sonolento"
    else:
        humor = "Misterioso"
    
    print(f"O dragão de escamas {cor_escamas} parece estar {humor}.")

cor = input("Digite a cor das escamas do dragão: ")
humor_dragao(cor)