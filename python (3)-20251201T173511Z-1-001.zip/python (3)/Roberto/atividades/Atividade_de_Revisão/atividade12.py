while True:
    print("\nMenu do Pequeno Alquimista")
    print("1: Misturar Ingredientes")
    print("2: Aquecer Caldeirão")
    print("0: Sair do Laboratório")

    escolha = input("Escolha uma opção: ")

    if escolha == "1":
        print("Você mistura pós coloridos...")
    elif escolha == "2":
        print("O caldeirão começa a borbulhar...")
    elif escolha == "0":
        print("Até a próxima experiência!")
        break
    else:
        print("Opção desconhecida.")
