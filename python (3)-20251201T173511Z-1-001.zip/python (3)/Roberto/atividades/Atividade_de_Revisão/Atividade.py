print("Você está vendo um post sobre um gatinho astronauta!")
print("Como você quer reagir?\n gostei, asmei, surpreso")

recao = input("Digite a sua reação: ")
if recao == "gostei":
    print("Reação registrada: Você gostou do gatinho astronauta!")
elif recao == "asmei":
    print("Reação registrada: Você ASMOU o gatinho astronauta! <3")
elif recao == "surpreso":
    print("Reação registrada: Você ficou SUPRESO com o gatinho astronauta!")
else:
    print("Reação inválida!")
    print("Você pode reagir com 'gostei', 'asmei' ou 'surpreso'.")