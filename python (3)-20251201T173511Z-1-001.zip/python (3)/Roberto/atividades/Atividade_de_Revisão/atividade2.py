print("Voce estao preparando uma poção e a temperatura é CRUCIAL")

temperatura = int(input("Digite a temperatura: "))
if temperatura <=50:
    print("Muito Frio! A poção vai congelar!")
elif temperatura>=50 and temperatura <= 80:
    print("Temperatura perfeita! A poção borbulha suavimente!")
elif temperatura >80:
    print("Muito quente! A poção vai explodir!")