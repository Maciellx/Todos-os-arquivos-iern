N = int(input("Digite um número máximo: "))

for numero in range(1, N + 1):
    if numero % 7 == 0:
        print(numero)
