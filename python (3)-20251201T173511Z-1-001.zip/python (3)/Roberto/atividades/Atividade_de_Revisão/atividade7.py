def maquina_eco():
    while True:
        palavra = input("Digite algo: ")
        if palavra == "parar":
            print("ok desligando a maquina de ecos")
            break
        else:
            print("Eco!",palavra)
maquina_eco()