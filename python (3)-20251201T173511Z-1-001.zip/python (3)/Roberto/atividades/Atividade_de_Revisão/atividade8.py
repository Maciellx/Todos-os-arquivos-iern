def calcular_feitico(forca_feitico):
    energia = ((forca_feitico * 5)**3) + 1
    print("custo da energia usada:", energia)
forca_feitico = int(input("Digite a força do feitiço: "))
calcular_feitico(forca_feitico)