numero_secreto = 7
while True:
    tentativa = int(input("Adivinhe o número secreto (entre 1 e 10): "))
    if tentativa != numero_secreto:
        print("Tente novamente!")
    else:
        print("Correto! Você adivinhou o número secreto!")
        break