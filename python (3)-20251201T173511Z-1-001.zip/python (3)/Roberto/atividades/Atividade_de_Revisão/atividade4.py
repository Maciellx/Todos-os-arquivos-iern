armazenar = 0
for i in range(5):
    print("Dia:", i)
    gemas = int(input("Quantas gemas o golem encontrou naquele dia? "))
    armazenar = gemas+ armazenar
print(f" O golem encontrou {armazenar} gemas!")