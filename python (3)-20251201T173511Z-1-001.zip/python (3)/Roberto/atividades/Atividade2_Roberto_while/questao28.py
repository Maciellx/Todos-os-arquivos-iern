cap = float(input("Digite o capital inicial (R$): "))
ju = float(input("Digite a taxa de juros mensal (%): "))
me = int(input("Digite o número de meses: "))

taxa = ju / 100

mes = 1

while mes <= me:
    cap += cap * taxa
    mes += 1

print(f"Após {me} meses, o saldo final será de R$ {cap:.2f}")
