numero = int(input("Digite um número: "))

soma = 0

i = 1

while i <= numero:
    soma += i 
    i += 2      

print("A soma dos números ímpares até", numero, "é:", soma)
