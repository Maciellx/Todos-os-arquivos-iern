n = int(input("Digite um número: "))

i = 0
while i <= n:
    print(f"2**{i} = {2**i}")
    i += 1
