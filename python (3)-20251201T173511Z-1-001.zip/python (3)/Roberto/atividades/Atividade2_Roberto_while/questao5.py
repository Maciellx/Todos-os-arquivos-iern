num = int(input("Digite um numero para saber todos os seus multiplos de 3: "))

num1 = 0
num2 = 7
while num2 <= num:
    num1 += num2
    num2 += 7

print(num1)