
num1 = 0
num2 = 1


contador = 0


while contador < 100:
    print(num1)

    proximo = num1 + num2
    num1 = num2
    num2 = proximo
    contador += 1
