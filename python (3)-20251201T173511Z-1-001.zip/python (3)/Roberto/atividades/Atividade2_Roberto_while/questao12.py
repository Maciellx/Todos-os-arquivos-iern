con = 1

while con == 1:
    saque = int(input("Digite o saque: "))
    if saque %10 == 0:
        print("saque permitido")
        con = 2
    else:
        print("Saque negado")