tentativas = 5  
numero_secreto = 4  

while tentativas > 0:
    print(f"Você tem {tentativas} tentativas restantes.")
    num = int(input("Tente adivinhar o número de 1 a 10: "))

    if num == numero_secreto:
        print("Parabéns! Você acertou! 🎉")
        break
    else:
        print("Você errou, tente novamente.")
        tentativas -= 1

if num != numero_secreto:
    print("Que pena! Você perdeu. O número era", numero_secreto)
