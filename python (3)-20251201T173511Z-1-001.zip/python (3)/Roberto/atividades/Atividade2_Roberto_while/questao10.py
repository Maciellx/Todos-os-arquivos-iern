num = int(input("Digite o numero para saber se todos os numero impares: "))

while num >=0:
    print("digite um numero negativo")
    num = int(input("Digite o numero para saber se todos os numero impares: "))
print("PARABENS VOCE DIGITOU UM NUMERO NEGATIVO")