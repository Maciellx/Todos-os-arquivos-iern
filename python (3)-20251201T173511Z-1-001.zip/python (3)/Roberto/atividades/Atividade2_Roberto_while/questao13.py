num = int(input("Digite um numero: "))

while num !=0:
    print (num)
    num -=1