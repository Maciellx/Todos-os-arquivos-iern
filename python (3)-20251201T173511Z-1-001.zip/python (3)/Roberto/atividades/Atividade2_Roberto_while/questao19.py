num = int(input("DIgite um numero: "))

soma = 0
contador = 1

while contador <=num:
    soma += 1/ contador
    contador += 1

print(f"soma das series {soma: .2f}")