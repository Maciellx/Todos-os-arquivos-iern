num = int(input("Digite um numero para saber os 10 primerio multiplos: "))

contador = 10
save = num
while contador >0:
    print(num)
    num += save
    contador-=1