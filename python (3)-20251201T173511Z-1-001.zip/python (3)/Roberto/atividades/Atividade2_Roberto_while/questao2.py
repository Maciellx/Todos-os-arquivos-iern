sair = 2

while sair == 2 :
    celsius = float(input("Digite a temperatura em Celsius: "))
    fahrenheit = (celsius * 9/5) + 32
    print(f"A temperatura em Fahrenheit é {fahrenheit:.2f}°F")
    sair = int(input("Digite 1 para sair e 2 para continuar: "))