opcao = 0

while opcao in [1, 2, 3] or opcao == 0:
    print("\nMenu:")
    print("1 - Dizer 'Olá'")
    print("2 - Dizer 'Tchau'")
    print("3 - Sair do programa")
    
    opcao = int(input("Escolha uma opção: "))
    
    if opcao == 1:
        print("Olá!")
    elif opcao == 2:
        print("Tchau!")
    elif opcao == 3:
        print("Saindo do programa...")
        break
    else:
        print("Opção inválida. Encerrando o programa.")
        break
