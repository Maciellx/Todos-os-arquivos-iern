senha ="1234"

tentativa = str(input("Digite a senha: "))
while tentativa != senha:
    print("tente novamente")
    tentativa = str(input("Digite a senha novamente: "))

print("PArabens voce acertou")