letra = str(input("Digite uma frase ou uma letra: "))
numero = int(input("Digite a quantidade de vezes que ira se repitir: "))

while numero >0:
    print(letra)
    numero -=1