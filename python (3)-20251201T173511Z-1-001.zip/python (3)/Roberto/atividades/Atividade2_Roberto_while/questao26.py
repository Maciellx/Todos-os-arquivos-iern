num = int(input("Digite um número: "))

soma = 0

divisor = 1

while divisor < num:
    if num % divisor == 0:
        soma += divisor
    divisor+= 1

if soma == num:
    print(f"numero perfeito {soma}")

else:
    print("Nao é perfeito")