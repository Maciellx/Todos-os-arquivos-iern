contador = 1
quantidade = 0
soma = 0
while contador >0:
    num1 = int(input("Digite notas: "))
    if num1 >0:
        soma += num1
        quantidade += 1
    else:
        print(f"{soma/quantidade}")
        contador = -2