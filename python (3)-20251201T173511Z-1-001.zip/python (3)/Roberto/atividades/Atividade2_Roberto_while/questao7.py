num = -100

while num <=100:
    print(num)
    num += 2