numero = int(input("Digite um número: "))

contador = numero-1

while contador > 1:
    if numero % contador == 0:
        print(numero, "não é primo!")
        break
    contador = contador-1

if contador == 1:
    print(f"o número {numero} é primo")