capacidade = int(input("Digite a capacidade do tanque em litros: "))
litros = int(input("Digite a quantos litros o tanque ira encher por segundo: "))

segundos = 1
salva = litros
while capacidade > litros:
    litros += salva
    segundos+=1

print(f"o tanque com capacidade {capacidade} vai demorar {segundos} segundos para encher com {salva} litros por segundos")