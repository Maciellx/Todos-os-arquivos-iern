num = int(input("Digite um número para saber seu fatorial: ")) 
save = num 
fat = 1 
while save > 1:
    fat *= save 
    save -=1 
    
print(fat)