numero_decimal = int(input("digite um numero para saber seu decimal: "))
numero_binario = 0
potencia = 1

if numero_decimal <= 0:
    print("Numero igual a 0 ou menor")

while numero_decimal>0:
    resto = numero_decimal %2
    numero_binario += resto*potencia
    numero_decimal = numero_decimal // 2
    potencia *= 10

print(f"o número binario é: {numero_binario}")