print("1- Ligar")
print("1- desligar")

on = int(input("Digite o numero: "))

while on == 1:
    print("A lampada esta ligada")

    print("\n1- Ligar")
    print("1- desligar")
    on = int(input("Digite o numero: "))

while on == 2:
    print("A lampada esta desligada")
    print("\n1- Ligar")
    print("1- desligar")
    on = int(input("Digite o numero: "))