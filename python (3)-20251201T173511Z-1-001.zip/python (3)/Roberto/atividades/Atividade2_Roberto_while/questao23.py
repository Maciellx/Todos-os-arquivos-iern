contador = 1
num = int(input("Digite numeros: "))

maior = 0
menor = num

while contador == 1:
    num = int(input("Digite numeros: "))

    if num > maior:
        maior = num
    elif num < menor and contador < menor:
        menor = num
    elif num == 0:
        print(f"O maior numero é {maior} e o menor é {menor}")
        contador = 0