aluno = str(input("Digite seu nome: "))

iern = 0

while iern <= 100:
    print(f"Boas-Vindas {aluno}")
    iern = iern + 1