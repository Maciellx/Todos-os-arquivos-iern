impar = 10

while impar <= 100:
    print(impar)
    impar += 1