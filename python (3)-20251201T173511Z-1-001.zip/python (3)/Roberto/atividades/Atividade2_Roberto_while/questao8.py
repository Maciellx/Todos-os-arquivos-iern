num = int(input("Digite o numero para saber se todos os numero impares: "))

impar = 1

while impar <= num:
    print(impar)
    impar += 2