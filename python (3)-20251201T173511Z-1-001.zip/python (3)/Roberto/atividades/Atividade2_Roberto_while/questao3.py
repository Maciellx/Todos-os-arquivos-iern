contador = 1
while contador == 1:

    tab = 0
    num = int(input("Digite um numero para somar: "))
    while tab <= 10:
        print(f"{num} + {tab} = {num + tab}")
        tab = tab + 1

    tab = 0
    num = int(input("Digite um numero para subitrair: "))
    while tab <= 10:
        sub = tab - num
        if sub <0:
          sub = sub *-1
          print(f"{tab} - {num} = {sub}")
        else:
            print(f"{tab} - {num} = {sub}")
        tab = tab + 1

    tab = 0
    num = int(input("Digite um numero para multiplicar: "))
    while tab <= 10:
        print(f"{num} x {tab} = {num * tab}")
        tab = tab + 1

    tab = 0
    num = int(input("Digite um numero para dividir: "))
    while tab <= 10:
        if num == 0:
            print("Não é posivel dividir por 0 ")
        else:
            print(f"{tab} / {num} = {tab/num}")
            tab = tab + 1
    print("1- Sim")
    print("2- Não")
    contador = int(input("Deseja saber a tabuada de outro numero? "))