class Moto: 
    def __init__(self, marca, modelo, ano, cor):
        self.marca = marca
        self.modelo = modelo 
        self.ano = ano 
        self.cor = cor 
    def ligar(self):
        print(f"A {self.modelo} está ligada.")

    def acelerar(self):
        print(f"A {self.modelo} está acelerando.")

    def frear(self):
        print(f"A {self.modelo} está freando.")

    def detalhes(self):
        print(f"moto:{self.marca} {self.modelo} \nAno:{self.ano} \nCor:{self.cor}")  

# Criando um objeto da classe carro
minha_moto = Moto("XRE 300", "Pop 110", 2025, "vermelha")

# Chamando os métodos do objeto
minha_moto.ligar()
minha_moto.acelerar()
minha_moto.frear()
minha_moto.detalhes()