class Pessoa: 
    def __init__(self, nome, idade, altura):
        self.nome = nome
        self.idade = idade
        self.altura = altura
    def apresentar(self):
        print(f"Olá, meu nome é {self.nome}, tenho {self.idade} anos e {self.altura}m de altura.")

    def envelhecer(self):
        self.idade += 1
        print(f"{self.nome} fez aniversário! Agora tem {self.idade} anos.")

# Criando objetos de classe Pessoa
pessoa1 = Pessoa("Jadson Kauã", 18, 1.66)
pessoa2 = Pessoa("Maria Cecília", 25, 1.50)

# Chamando os métodos dos objetos
pessoa1.apresentar()
pessoa2.apresentar()

pessoa1.envelhecer()