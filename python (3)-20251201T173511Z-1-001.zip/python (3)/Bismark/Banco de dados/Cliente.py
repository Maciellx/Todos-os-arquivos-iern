class CLiente:
    def __init__(self, nome, idade, telefone, cpf, endereco, escolaridade, estado_civil):
        self.nome = nome
        self.idade = idade
        self.telefone = telefone
        self.cpf = cpf
        self.endereco = endereco
        self.escolaridade = escolaridade
        self.estado_civil = estado_civil

    def exibir_dados(self):
        print("\n --- Dados do Cliente ---")
        print(f"Nome: {self.nome}")
        print(f"Idade: {self.idade}")
        print(f"Telefone: {self.telefone}")
        print(f"CPF: {self.cpf}")
        print(f"Endereço: {self.endereco}")
        print(f"Escolaridade: {self.escolaridade}")
        print(f"Estado Civil: {self.estado_civil}")
    
def cadastrar_cliente():
    nome = input("Digite o nome: ")
    idade = input("Digite a idade: ")
    telefone = input("Digite o telefone: ")
    cpf = input("Digite o CPF: ")
    endereco = input("Digite o endereço: ")
    escolaridade = input("Digite a escolaridade: ")
    estado_civil = input("Digite o estado civil: ")

    cliente = CLiente(nome, idade, telefone, cpf, endereco, escolaridade, estado_civil)

    return cliente

def main():
    print("=== Sistema de Cadastro de Clientes ===")

    cliente_cadastrado = cadastrar_cliente()

    cliente_cadastrado.exibir_dados()

if __name__ == "__main__":
    main()