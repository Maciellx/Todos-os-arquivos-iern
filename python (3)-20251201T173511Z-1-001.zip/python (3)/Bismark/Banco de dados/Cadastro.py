class Cliente: #Definição de classe
    def __init__(self, nome, idade, saldo): #Metodo construtor de classe
        self.nome = nome #Definição de nome
        self.idade = idade  #Definição de idade
        self.saldo = saldo  #Definição de saldo

    def exibir_informacoes(self): #Metodo para exibir as informações dp cliente
        print(f"Cliente: {self.nome}, Idade: {self.idade}, Saldo: {self.saldo: .2f}")
    
    def depositar(self, valor): #Metodo para exibir o deposito doi cliente
        self.saldo += valor
        print(f"Deposito de {valor:.2f} realizado com sucesso")
    
    def sacar(self, valor):#Metodo para exibir o saque do cliente
        if valor <= self.saldo:
            self.saldo -= valor
            print(f"Saque de {valor:.2f} realizado com sucesso")
        else:
            print("Saldo insuficiente.")

# Solicitando dados do usuário
nome = input("Digite o nome do cliente: ")
idade = int(input("Digite a idade do cliente: "))
saldo = float(input("Digite o saldo inicial do cliente: "))

# Criando um cliente com os dados inseridos
cliente1 = Cliente(nome, idade, saldo)

while True:
    print("\n1. Exibir informações")
    print("2. Depositar")
    print("3. Sacar")
    print("4. Sair")
    opcao = input("Escolha uma opção: ")
    
    if opcao == "1":
        cliente1.exibir_informacoes()
    elif opcao == "2":
        valor = float(input("Digite o valor do depósito: "))
        cliente1.depositar(valor)
    elif opcao == "3":
        valor = float(input("Digite o valor do saque: "))
        cliente1.sacar(valor)
    elif opcao == "4":
        print("Saindo...")
        break
    else:
        print("Opção inválida. Tente novamente.")
