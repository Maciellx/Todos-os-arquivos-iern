class Livro:
    def __init__(self, titulo, autor, ano):
        self.titulo = titulo
        self.autor = autor
        self.ano = ano

    def exibir_detalhes(self):
        print(f"Livro: {self.titulo}, Autor: {self.autor}, Ano: {self.ano}")

class Biblioteca:
    def __init__(self):
        self.livros = []  # Corrigido para plural

    def adicionar_livro(self, livro):
        self.livros.append(livro)
        print(f"O livro '{livro.titulo}' foi adicionado à biblioteca!")

    def listar_livros(self):
        print("\nLista da Biblioteca:")
        for livro in self.livros:
            livro.exibir_detalhes()

# Criando alguns livros
livro1 = Livro("Aventuras no Código", "João Silva", 2020)
livro2 = Livro("Python para Iniciantes", "Maria Souza", 2021)

# Criando a biblioteca
biblioteca = Biblioteca()

# Adicionando os livros
biblioteca.adicionar_livro(livro1)
biblioteca.adicionar_livro(livro2)

# Listando os livros cadastrados
biblioteca.listar_livros()
