class Animal:
    def falar(self):
        return "O animal faz um som genérico"

class Cachorro(Animal):
    def falar(self):
        return "O cachorro late"

class Gato(Animal):
    def falar(self):
        return "O gato mia"

class Pato(Animal):
    def falar(self):
        return "O pato grasna"

animais = [Cachorro(), Gato(), Pato()]
for animal in animais:
    print(animal.falar())