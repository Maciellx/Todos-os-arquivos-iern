class professor():
    def __init__(self,nome, diciplina, tempo_experiencia,email, ):
        self.nome = nome
        self.diciplina = diciplina
        self.tempo_experiencia = tempo_experiencia
        self.email = email

    def exibir(self):
        print(f'Nome: {self.nome}')
        print(f'Disciplina: {self.diciplina}')
        print(f'Tempo de Experiencia: {self.tempo_experiencia} anos')
        print(f'Email: {self.email}')

nome = input('Digite o nome do professor: ')
diciplina = input('Digite a disciplina do professor: ')
tempo_experiencia = input('Digite o tempo de experiencia do professor: ')
email = input('Digite o email do professor: ')

professor1 = professor(nome, diciplina, tempo_experiencia, email)
professor1.exibir()