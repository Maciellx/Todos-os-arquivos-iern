class Agendamento():
    def __init__(self, data, hora, cliente,especialidade):
        self.data = data
        self.hora = hora
        self.cliente = cliente
        self.especialidade = especialidade

    def exibir_agendamento(self):
        print(f"Data: {self.data}")
        print(f"Hora: {self.hora}")
        print(f"Cliente: {self.cliente}")
        print(f"Especialidade: {self.especialidade}")

data = input("Digite a data do agendamento (DD/MM/AAAA): ")
hora = input("Digite a hora do agendamento (HH:MM): ")
cliente = input("Digite o nome do cliente: ")
especialidade = input("Digite a especialidade: ")

agendamento = Agendamento(data, hora, cliente, especialidade)
agendamento.exibir_agendamento()