nome = input("Digite seu nome: ")
idade = int(input("Digite sua idade: "))
cidade = input("digite sua cidade: ")

if idade >18:
    status = "Maior de idade"

elif idade <18:
    status = "Menor de idade"

print("\nOla,"+nome+"!")
print("Você tem",idade,"anos e mora em",cidade+".")
print("De acordo com a sua idade e cidade, você é",status+".")

print("\n obrigado por usar nosso programa!")