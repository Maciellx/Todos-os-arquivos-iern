class Paciente:
    def __init__(self, nome,idade, cidade, telefone, endereco,):
        self.nome = nome
        self.idade = idade
        self.cidade = cidade
        self.telefone = telefone
        self.endereco = endereco

    def exibir_dados(self):
        print(f"Nome: {self.nome}")
        print(f"Idade: {self.idade}")
        print(f"Cidade: {self.cidade}")
        print(f"Telefone: {self.telefone}")
        print(f"Endereço: {self.endereco}")

nome = input("Digite o nome do paciente: ")
idade = input("Digite a idade do paciente: ")
cidade = input("Digite a cidade do paciente: ")
telefone = input("Digite o telefone do paciente: ")
endereco = input("Digite o endereço do paciente: ")

paciente1 = Paciente(nome, idade, cidade, telefone, endereco)
paciente1.exibir_dados()