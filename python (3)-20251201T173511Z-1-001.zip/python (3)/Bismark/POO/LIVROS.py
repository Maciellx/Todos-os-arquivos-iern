class Livros():

    def __init__(self, titulo, autor, editora, ano_publicacao):
        self.titulo = titulo
        self.autor = autor
        self.editora = editora
        self.ano_publicacao = ano_publicacao

    def exibir_informacoes(self):
        print(f'Título: {self.titulo}')
        print(f'Autor: {self.autor}')
        print(f'Editora: {self.editora}')
        print(f'Ano de Publicação: {self.ano_publicacao}')

titulo = input('Digite o título do livro: ')
autor = input('Digite o autor do livro: ')
editora = input('Digite a editora do livro: ')
ano_publicacao = input('Digite o ano de publicação do livro: ')

livro = Livros(titulo, autor, editora, ano_publicacao)
livro.exibir_informacoes()