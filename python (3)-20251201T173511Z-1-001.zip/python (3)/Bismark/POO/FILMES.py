class filmes:
    def __init__(self, titulo, diretor, ano ,genero):
        self.titulo = titulo
        self.diretor = diretor
        self.ano = ano
        self.genero = genero
    def exibir(self):
        print(f'Titulo: {self.titulo}')
        print(f'Diretor: {self.diretor}')
        print(f'Ano: {self.ano}')
        print(f'Genero: {self.genero}')

titulo = input('Digite o título do filme: ')
diretor = input('Digite o nome do diretor: ')
ano = int(input('Digite o ano de lançamento: '))
genero = input('Digite o gênero do filme: ')


filme = filmes(titulo, diretor, ano, genero)
filme.exibir()