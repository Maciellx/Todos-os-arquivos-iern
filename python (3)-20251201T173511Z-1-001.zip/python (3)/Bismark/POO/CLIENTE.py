class cliente():
    def __init__(self, nome, cpf,telefone,email):
        self.nome = nome
        self.cpf = cpf
        self.telefone = telefone
        self.email = email

    def exibir_dados(self):
        print(f"Nome: {self.nome}")
        print(f"CPF: {self.cpf}")
        print(f"Telefone: {self.telefone}")
        print(f"Email: {self.email}")

nome = input("Digite o nome do cliente: ")
cpf = input("Digite o CPF do cliente: ")
telefone = input("Digite o telefone do cliente: ")
email = input("Digite o email do cliente: ")

cliente1 = cliente(nome, cpf, telefone, email)
cliente1.exibir_dados()