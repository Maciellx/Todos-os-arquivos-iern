class usuario:
    def __init__(self, nome, email):
        self.nome = nome
        self.email = email

    def exibir_dados(self):
        return f"Nome:{self.nome}, Email:{self.email}"
    
    def atualizar_email(self, novo_email):
        if "@" in novo_email:
            self._email = novo_email
        else:
            print("Email Inválido")
        
class aluno(usuario):
    def __init__(self, nome, email, matricula):
        super().__init__(nome, email)
        self.matricula = matricula
    
    def exibir_dados(self):
        dados_basicos = super().exibir.dados()
        return f"{dados_basicos}, Matricula:{self.matricula}"
    
print("Bem-Vindo ao Sistema de cadastro!" \
      "")
tipo = input("Você quer cadastrar um (1) Usuário ou (2) Aluno? Digite 1 ou 2: ")
nome = input("Digite o nome: ")
email = input("Digite o e-mail: ")

if tipo == "1":
    usuario = usuario(nome, email)
    print("\n Usuário cadastro com sucesso!")
elif tipo == "2":
    matricula = input("Digite a matricula")
    aluno = aluno(nome, email, matricula)
    print("\n Aluno cadastrado com sucesso! ")
    print(aluno.exibir_dados())
else:
    print("Opção invalida")