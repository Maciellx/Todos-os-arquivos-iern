use empresa;

create table funcionarios(
	nome varchar(70),
    idade varchar(70),
    cargo varchar(70),
    salario varchar(70)
);

INSERT INTO funcionarios(nome, idade, cargo, salario) VALUES
('João Pereira', '40 anos', 'CEO (Diretor Executivo)','R$ 25.000,00'),
('Carla Mendes','35 anos', 'Gerente de Recursos Humanos', 'R$ 12.000,00'),
('Felipe Rocha','30 anos', 'Coordenador de TI', 'R$ 9.500,00'),
('Ana Souza', '27 anos', 'Analista de Marketing', 'R$ 6.800,00'),
('Pedro Lima','24 anos', 'Assistente Financeiro', 'R$ 4.500,00'),
('Mariana Silva','22 anos', 'Estagiária de Administração', 'R$ 1.800,00');