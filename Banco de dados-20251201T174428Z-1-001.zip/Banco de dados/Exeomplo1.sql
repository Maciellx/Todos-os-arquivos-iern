use sistema_filmes;
create table clientes(
	nome varchar(100),
    idade int,
    telefone int,
    email varchar(100),
    forma_de_pagamento varchar(100)
);

create table filmes(
	nome_do_filme varchar(100),
    ano_do_filme int,
    genero varchar(100),
    nome_do_diretor varchar(100)
);

