use cadastro_cliente;

create table cliente(
	nome varchar(100),
    email varchar(100),
    telefone varchar(100)
);

INSERT INTO cliente(nome, email, telefone) VALUES
('Carlos Silva', 'carlos@gmail.com', '849998303030'),
('Ana Souza', 'ana@gmail.com', '8499929299'),
('Marcos Pereira', 'marcos@gmail.com', '84999161809');
