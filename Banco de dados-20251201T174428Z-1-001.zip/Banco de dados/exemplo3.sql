use agenda;

create table compromissos (
	data_evento date,
    descricao text
);

insert into compromissos (data_evento, descricao)values
('2025-04-10','reunião do fornecedor'),
('2025-04-15','consulta medica'), 
('2025-04-20','viagem a natal');