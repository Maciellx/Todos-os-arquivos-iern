use instituicao_db; 
# Seleciona o banco de dados instituicao_db

create table clientes( # cria um tabela
	id int primary key,           # Cria uma coluna id do tipo inteiro
    nome varchar(50)              # Cria uma coluna nome
);

create table pedidos( #cria uma tabela com o nome pedidos
	id int primary key,           # Cria uma coluna id' como chave primária
    cliente_id int,               # Cria uma coluna cliente_id
    produto varchar(50),          # Cria uma coluna produto 
    foreign key (cliente_id) references clientes (id)  # Define 'cliente_id' como chave estrangeira
);

insert into clientes values (1,'Ana'),(2,'João'); # Insere dois registros na tabela


insert into pedidos values (1,1,'livro'),(2,2,'caderno'),(3,1,'Caneta'); # Insere três pedidos

select #seleciona as tabelas
	clientes.id as cliente_id, #
    clientes.nome,            
    pedidos.id as pedidos_id, 
    pedidos.produto             
from clientes
inner join pedidos on clientes.id = pedidos.cliente_id; # juntas as duas tabelas
